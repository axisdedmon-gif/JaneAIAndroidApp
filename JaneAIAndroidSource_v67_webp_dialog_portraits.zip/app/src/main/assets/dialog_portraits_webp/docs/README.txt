APK-optimized WebP portrait pack.
Each image keeps the same base avatar filename but uses .webp.
Kadi_a: 23 portraits
Kadi_b: 23 portraits
Kadi_c: 23 portraits
