package com.example.janeai;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final String BACKEND_TTS_URL = "https://jane-elevenlabs-backend.onrender.com/api/tts";

    private WebView webView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private MediaPlayer mediaPlayer;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        webView.addJavascriptInterface(new JaneVoiceBridge(), "AndroidJane");

        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void notifyJs(String functionName, String message) {
        mainHandler.post(() -> {
            String safeMessage = message == null ? "" : message.replace("\\", "\\\\").replace("'", "\\'");
            webView.evaluateJavascript("window." + functionName + " && window." + functionName + "('" + safeMessage + "');", null);
        });
    }

    private void stopAudio() {
        mainHandler.post(() -> {
            try {
                if (mediaPlayer != null) {
                    mediaPlayer.stop();
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
            } catch (Exception ignored) {}
            notifyJs("JaneNativeAudioDone", "");
        });
    }

    public class JaneVoiceBridge {
        @JavascriptInterface
        public void speak(String text) {
            new Thread(() -> {
                try {
                    stopAudio();

                    URL url = new URL(BACKEND_TTS_URL);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(30000);
                    connection.setReadTimeout(60000);
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Content-Type", "application/json");
                    connection.setRequestProperty("Accept", "audio/mpeg");

                    String escapedText = text == null ? "" : text
                        .replace("\\", "\\\\")
                        .replace("\"", "\\\"")
                        .replace("\n", "\\n")
                        .replace("\r", "\\r");

                    String body = "{\"text\":\"" + escapedText + "\"}";
                    byte[] bodyBytes = body.getBytes(StandardCharsets.UTF_8);

                    try (OutputStream os = connection.getOutputStream()) {
                        os.write(bodyBytes);
                    }

                    int status = connection.getResponseCode();
                    InputStream inputStream = status >= 200 && status < 300
                        ? connection.getInputStream()
                        : connection.getErrorStream();

                    if (status < 200 || status >= 300) {
                        StringBuilder error = new StringBuilder();
                        if (inputStream != null) {
                            byte[] buffer = new byte[1024];
                            int read;
                            while ((read = inputStream.read(buffer)) != -1) {
                                error.append(new String(buffer, 0, read, StandardCharsets.UTF_8));
                            }
                        }
                        throw new RuntimeException("Voice server error " + status + ": " + error);
                    }

                    File audioFile = new File(getCacheDir(), "jane_voice.mp3");
                    try (FileOutputStream fos = new FileOutputStream(audioFile)) {
                        byte[] buffer = new byte[8192];
                        int read;
                        while ((read = inputStream.read(buffer)) != -1) {
                            fos.write(buffer, 0, read);
                        }
                    }

                    mainHandler.post(() -> {
                        try {
                            mediaPlayer = new MediaPlayer();
                            mediaPlayer.setAudioAttributes(
                                new AudioAttributes.Builder()
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                    .build()
                            );
                            mediaPlayer.setDataSource(audioFile.getAbsolutePath());
                            mediaPlayer.setOnPreparedListener(player -> {
                                notifyJs("JaneNativeAudioStarted", "");
                                player.start();
                            });
                            mediaPlayer.setOnCompletionListener(player -> {
                                player.release();
                                mediaPlayer = null;
                                notifyJs("JaneNativeAudioDone", "");
                            });
                            mediaPlayer.setOnErrorListener((player, what, extra) -> {
                                try { player.release(); } catch (Exception ignored) {}
                                mediaPlayer = null;
                                notifyJs("JaneNativeAudioError", "Audio playback error.");
                                return true;
                            });
                            mediaPlayer.prepareAsync();
                        } catch (Exception playbackError) {
                            notifyJs("JaneNativeAudioError", playbackError.getMessage());
                        }
                    });
                } catch (Exception error) {
                    notifyJs("JaneNativeAudioError", error.getMessage());
                }
            }).start();
        }

        @JavascriptInterface
        public void stop() {
            stopAudio();
        }
    }
}
