package com.example.janeai;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.database.Cursor;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final String BACKEND_TTS_URL = "https://jane-elevenlabs-backend.onrender.com/api/tts";
    private static final int PICK_FILE_REQUEST = 7042;

    private WebView webView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private MediaPlayer mediaPlayer;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        webView.addJavascriptInterface(new JaneBridge(), "AndroidJane");
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private String jsString(String value) {
        if (value == null) return "";
        return value
            .replace("\\", "\\\\")
            .replace("'", "\\'")
            .replace("\n", "\\n")
            .replace("\r", "\\r");
    }

    private void notifyJs(String functionName, String message) {
        mainHandler.post(() -> {
            webView.evaluateJavascript(
                "window." + functionName + " && window." + functionName + "('" + jsString(message) + "');",
                null
            );
        });
    }

    private void stopAudio() {
        mainHandler.post(() -> {
            try {
                if (mediaPlayer != null) {
                    mediaPlayer.stop();
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
            } catch (Exception ignored) {}
            notifyJs("JaneNativeAudioDone", "");
        });
    }

    private String getFileName(Uri uri) {
        String result = "uploaded-file";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (nameIndex >= 0) {
                    String name = cursor.getString(nameIndex);
                    if (name != null && !name.trim().isEmpty()) result = name;
                }
            }
        } catch (Exception ignored) {}
        return result;
    }

    private String getMimeType(Uri uri) {
        String type = getContentResolver().getType(uri);
        return type == null || type.trim().isEmpty() ? "application/octet-stream" : type;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_FILE_REQUEST) return;

        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            notifyJs("JaneFilePickCancelled", "");
            return;
        }

        Uri uri = data.getData();
        new Thread(() -> {
            try {
                String name = getFileName(uri);
                String mimeType = getMimeType(uri);
                ByteArrayOutputStream output = new ByteArrayOutputStream();

                try (InputStream input = getContentResolver().openInputStream(uri)) {
                    if (input == null) throw new RuntimeException("Could not open selected file.");
                    byte[] buffer = new byte[8192];
                    int read;
                    int total = 0;
                    int maxBytes = 10 * 1024 * 1024;
                    while ((read = input.read(buffer)) != -1) {
                        total += read;
                        if (total > maxBytes) throw new RuntimeException("File is too large. Please choose a file under 10MB.");
                        output.write(buffer, 0, read);
                    }
                }

                String base64 = Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP);
                mainHandler.post(() -> {
                    String js = "window.JaneReceiveFile && window.JaneReceiveFile('" +
                        jsString(name) + "','" + jsString(mimeType) + "','" + jsString(base64) + "');";
                    webView.evaluateJavascript(js, null);
                });
            } catch (Exception error) {
                notifyJs("JaneFilePickError", error.getMessage());
            }
        }).start();
    }

    public class JaneBridge {
        @JavascriptInterface
        public void speak(String text) {
            new Thread(() -> {
                try {
                    stopAudio();

                    URL url = new URL(BACKEND_TTS_URL);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(30000);
                    connection.setReadTimeout(60000);
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Content-Type", "application/json");
                    connection.setRequestProperty("Accept", "audio/mpeg");

                    String escapedText = text == null ? "" : text
                        .replace("\\", "\\\\")
                        .replace("\"", "\\\"")
                        .replace("\n", "\\n")
                        .replace("\r", "\\r");

                    String body = "{\"text\":\"" + escapedText + "\"}";
                    try (OutputStream os = connection.getOutputStream()) {
                        os.write(body.getBytes(StandardCharsets.UTF_8));
                    }

                    int status = connection.getResponseCode();
                    InputStream inputStream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();

                    if (status < 200 || status >= 300) {
                        StringBuilder error = new StringBuilder();
                        if (inputStream != null) {
                            byte[] buffer = new byte[1024];
                            int read;
                            while ((read = inputStream.read(buffer)) != -1) {
                                error.append(new String(buffer, 0, read, StandardCharsets.UTF_8));
                            }
                        }
                        throw new RuntimeException("Voice server error " + status + ": " + error);
                    }

                    File audioFile = new File(getCacheDir(), "jane_voice.mp3");
                    try (FileOutputStream fos = new FileOutputStream(audioFile)) {
                        byte[] buffer = new byte[8192];
                        int read;
                        while ((read = inputStream.read(buffer)) != -1) {
                            fos.write(buffer, 0, read);
                        }
                    }

                    mainHandler.post(() -> {
                        try {
                            mediaPlayer = new MediaPlayer();
                            mediaPlayer.setAudioAttributes(new AudioAttributes.Builder()
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .build());
                            mediaPlayer.setDataSource(audioFile.getAbsolutePath());
                            mediaPlayer.setOnPreparedListener(player -> {
                                notifyJs("JaneNativeAudioStarted", "");
                                player.start();
                            });
                            mediaPlayer.setOnCompletionListener(player -> {
                                player.release();
                                mediaPlayer = null;
                                notifyJs("JaneNativeAudioDone", "");
                            });
                            mediaPlayer.setOnErrorListener((player, what, extra) -> {
                                try { player.release(); } catch (Exception ignored) {}
                                mediaPlayer = null;
                                notifyJs("JaneNativeAudioError", "Audio playback error.");
                                return true;
                            });
                            mediaPlayer.prepareAsync();
                        } catch (Exception playbackError) {
                            notifyJs("JaneNativeAudioError", playbackError.getMessage());
                        }
                    });
                } catch (Exception error) {
                    notifyJs("JaneNativeAudioError", error.getMessage());
                }
            }).start();
        }

        @JavascriptInterface
        public void stop() {
            stopAudio();
        }

        @JavascriptInterface
        public void pickFile() {
            mainHandler.post(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {"image/*", "application/pdf", "text/plain"});
                try {
                    startActivityForResult(intent, PICK_FILE_REQUEST);
                } catch (ActivityNotFoundException error) {
                    notifyJs("JaneFilePickError", "No file picker is available on this device.");
                }
            });
        }
    }
}
