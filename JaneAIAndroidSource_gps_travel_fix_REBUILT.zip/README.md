# Jane AI Assistant Android APK Project

This is an Android WebView wrapper for the Jane AI Assistant HTML.

## Important

Do not put your ElevenLabs API key inside the Android app. APKs can be inspected. Keep the ElevenLabs key on a backend server.

The app loads:

```text
app/src/main/assets/index.html
```

and calls a backend TTS endpoint configured in:

```text
app/src/main/java/com/example/janeai/MainActivity.java
```

Change this line:

```java
private static final String BACKEND_TTS_URL = "https://YOUR-DOMAIN.com/api/tts";
```

to your hosted backend URL, for example:

```java
private static final String BACKEND_TTS_URL = "https://jane.yourdomain.com/api/tts";
```

You can use the `server.mjs` file from the previous ElevenLabs package as the backend.

## Build the APK in Android Studio

1. Open Android Studio.
2. Choose **Open**.
3. Select this folder: `JaneAIAndroidAPKProject`.
4. Wait for Gradle sync to finish.
5. Edit `MainActivity.java` and set `BACKEND_TTS_URL`.
6. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Android Studio will create an APK at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Install on Android

Transfer the APK to your Android phone, then open it. You may need to allow installs from unknown sources.

## Local phone testing

If your backend is running on your computer, use your computer's LAN IP address instead of localhost:

```java
private static final String BACKEND_TTS_URL = "http://192.168.1.42:3000/api/tts";
```

Make sure your phone and computer are on the same Wi-Fi network.
